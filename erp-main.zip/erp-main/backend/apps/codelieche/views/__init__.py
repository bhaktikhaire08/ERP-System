# -*- coding:utf-8 -*-

from .viewset import (
    ModelViewSet,
    ReadOnlyViewSet,
)
