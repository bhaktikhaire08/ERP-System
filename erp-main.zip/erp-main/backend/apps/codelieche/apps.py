from django.apps import AppConfig


class CodeliecheConfig(AppConfig):
    name = 'codelieche'
